import { Leaf, Truck, CheckCircle } from "lucide-react"

export function TrustBadges() {
  const badges = [
    {
      icon: Leaf,
      title: "100% Organic",
      description: "Certified organic fruits",
    },
    {
      icon: Truck,
      title: "Same-Day Delivery",
      description: "Order before 2 PM",
    },
    {
      icon: CheckCircle,
      title: "Fresh Guarantee",
      description: "Or your money back",
    },
  ]

  return (
    <section className="bg-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {badges.map((badge, index) => (
            <div key={index} className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
                <badge.icon className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                {badge.title}
              </h3>
              <p className="text-gray-600">{badge.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}