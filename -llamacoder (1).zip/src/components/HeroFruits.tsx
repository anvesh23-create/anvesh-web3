import { Fruit } from "../types"
import { Button } from "../components/ui/button"
import { Plus, ShoppingCart } from "lucide-react"

interface HeroFruitsProps {
  fruits: Fruit[]
  onAddToCart: (fruit: Fruit) => void
}

export function HeroFruits({ fruits, onAddToCart }: HeroFruitsProps) {
  return (
    <section className="relative bg-green-100 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl sm:text-5xl font-bold text-green-900 mb-4">
            Fresh From the Farm
          </h1>
          <p className="text-xl text-green-700 max-w-2xl mx-auto">
            Premium organic fruits delivered straight to your doorstep. 
            Taste the difference of farm-fresh quality.
          </p>
        </div>

        {/* Fruit Carousel */}
        <div className="overflow-x-auto pb-4">
          <div className="flex space-x-6" style={{ minWidth: "max-content" }}>
            {fruits.map((fruit) => (
              <div
                key={fruit.id}
                className="bg-white rounded-xl shadow-lg p-6 w-64 flex-shrink-0"
              >
                <div className="bg-gradient-to-br from-yellow-100 to-orange-100 rounded-lg h-40 mb-4 flex items-center justify-center">
                  <div className="text-6xl">
                    {fruit.image === "apple" && "🍎"}
                    {fruit.image === "orange" && "🍊"}
                    {fruit.image === "banana" && "🍌"}
                    {fruit.image === "strawberry" && "🍓"}
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {fruit.name}
                </h3>
                <p className="text-2xl font-bold text-green-600 mb-4">
                  ${fruit.price}
                  <span className="text-sm font-normal text-gray-500">/lb</span>
                </p>
                <Button
                  onClick={() => onAddToCart(fruit)}
                  className="w-full bg-green-600 hover:bg-green-700 text-white"
                >
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Add to Cart
                </Button>
              </div>
            ))}
          </div>
        </div>

        <div className="text-center mt-8">
          <Button
            size="lg"
            className="bg-yellow-500 hover:bg-yellow-600 text-white px-8 py-3 text-lg"
          >
            Shop All Fruits
          </Button>
        </div>
      </div>
    </section>
  )
}