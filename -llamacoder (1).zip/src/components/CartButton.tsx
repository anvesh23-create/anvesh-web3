import { ShoppingCart } from "lucide-react"
import { Button } from "../components/ui/button"

interface CartButtonProps {
  count: number
  onClick: () => void
}

export function CartButton({ count, onClick }: CartButtonProps) {
  return (
    <Button
      variant="outline"
      onClick={onClick}
      className="relative p-2 hover:bg-green-50 border-green-200"
    >
      <ShoppingCart className="w-6 h-6 text-green-700" />
      {count > 0 && (
        <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
          {count}
        </span>
      )}
    </Button>
  )
}