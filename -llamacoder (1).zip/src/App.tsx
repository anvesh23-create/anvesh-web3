import { useState } from "react"
import { HeroFruits } from "./components/HeroFruits"
import { CartButton } from "./components/CartButton"
import { PaymentModal } from "./components/PaymentModal"
import { TrustBadges } from "./components/TrustBadges"
import { CartItem, Fruit } from "./types"

const fruits: Fruit[] = [
  { id: 1, name: "Organic Apples", price: 4.99, image: "apple" },
  { id: 2, name: "Sweet Oranges", price: 3.99, image: "orange" },
  { id: 3, name: "Fresh Bananas", price: 2.49, image: "banana" },
  { id: 4, name: "Ripe Strawberries", price: 5.99, image: "strawberry" },
]

export default function App() {
  const [cart, setCart] = useState<CartItem[]>([])
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false)
  const [showSuccessToast, setShowSuccessToast] = useState(false)

  const addToCart = (fruit: Fruit) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === fruit.id)
      if (existing) {
        return prev.map(item =>
          item.id === fruit.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      }
      return [...prev, { ...fruit, quantity: 1 }]
    })
  }

  const removeFromCart = (id: number) => {
    setCart(prev => prev.filter(item => item.id !== id))
  }

  const updateQuantity = (id: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(id)
      return
    }
    setCart(prev =>
      prev.map(item =>
        item.id === id ? { ...item, quantity } : item
      )
    )
  }

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0)
  }

  const handlePayment = () => {
    setShowSuccessToast(true)
    setCart([])
    setIsPaymentModalOpen(false)
    setTimeout(() => setShowSuccessToast(false), 3000)
  }

  const cartItemCount = cart.reduce((total, item) => total + item.quantity, 0)

  return (
    <div className="min-h-screen bg-amber-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="text-2xl font-bold text-green-800">
                🍎 FreshHarvest Fruits
              </div>
            </div>
            <CartButton
              count={cartItemCount}
              onClick={() => setIsPaymentModalOpen(true)}
            />
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main>
        <HeroFruits fruits={fruits} onAddToCart={addToCart} />
        <TrustBadges />
      </main>

      {/* Footer */}
      <footer className="bg-green-800 text-white py-8 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-sm">
            © 2024 FreshHarvest Fruits. All rights reserved.
          </p>
        </div>
      </footer>

      {/* Payment Modal */}
      <PaymentModal
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        cart={cart}
        onUpdateQuantity={updateQuantity}
        onRemoveFromCart={removeFromCart}
        onPayment={handlePayment}
        totalPrice={getTotalPrice()}
      />

      {/* Success Toast */}
      {showSuccessToast && (
        <div className="fixed bottom-4 right-4 bg-green-600 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-pulse">
          ✓ Payment successful! Thank you for your order.
        </div>
      )}
    </div>
  )
}