export interface Fruit {
  id: number
  name: string
  price: number
  image: string
}

export interface CartItem extends Fruit {
  quantity: number
}